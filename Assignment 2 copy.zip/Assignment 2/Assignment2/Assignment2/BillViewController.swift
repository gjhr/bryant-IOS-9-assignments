//
//  BillViewController.swift
//  Assignment2
//
//  Created by Geoff Bryant on 7/2/16.
//  Copyright © 2016 Geoff Bryant. All rights reserved.
//

import Foundation

//
//  ViewController.swift
//  Assignment2
//
//  Created by Geoff Bryant on 7/2/16.
//  Copyright © 2016 Geoff Bryant. All rights reserved.
//


import UIKit

class BillViewController: UIViewController {
    
    
    
    
    @IBOutlet weak var checkTotalTextField: UITextField!
    
    @IBOutlet weak var tipPercentageTextField: UITextField!
    
    @IBOutlet weak var numberOfGuestTextField: UITextField!
    
    @IBOutlet weak var individualTotalLabel: UILabel!
    
//    @IBOutlet weak var totalWithTip: UILabel!
    
    
    //MARK : LIFECYCLE

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //MARK : ACTIONS
    


    @IBAction func billCalcButton(sender: UIButton) {
//        let checkTotalInt = Int(checkTotalTextField.text!)
        let tipInt = Int(tipPercentageTextField.text!)
//        let peopleInt = Int(numberOfGuestTextField.text!)
        let peopleInt = Double(numberOfGuestTextField.text!)
        let tipPercent = Double(tipInt!) * 0.01
//        let checkTotalDub = checkTotalInt!
//        let checkTotalDub = Double((checkTotalTextField.text! as NSString).doubleValue)
      let checkTotalDub = Double(checkTotalTextField.text!)
        let onePlusTipPercent = Double(tipPercent + 1)
          let totalWTip = Double(checkTotalDub! * onePlusTipPercent)
    
        
        
        if peopleInt == 0 {
//           totalWithTip.text = "\(onePlusTipPercent)"
          return individualTotalLabel.text = "N/A"
        } else if peopleInt == 1 {
                individualTotalLabel.text = "\(totalWTip)"
            }
        else {
          let finalTotal = Double(totalWTip / peopleInt!)
            let finalTotalString = String(format: "%.2f", finalTotal)
         individualTotalLabel.text = "$\(finalTotalString)"}
        }
    
    
        
        
    }




