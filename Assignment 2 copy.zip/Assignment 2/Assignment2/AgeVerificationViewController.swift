//
//  AgeVerificationViewController.swift
//  Assignment2
//
//  Created by Geoff Bryant on 7/2/16.
//  Copyright © 2016 Geoff Bryant. All rights reserved.
//

//extension NSDate {
//    var age:Int {
//        return NSCalendar.currentCalendar().components(NSCalendarUnit.Year,
//                        fromDate: self,
//                        toDate: NSDate(),,
////                        options: NSCalendarOptions(rawValue: 0)
////                            .year,
//    }
//}


import Foundation
import UIKit



class AgeVerificationViewController: UIViewController {
    
   
    
    @IBOutlet weak var birthYearTextField: UILabel!
    
    @IBOutlet weak var ageResultLabel: UILabel!
    
    
    //MARK : LIFECYCLE
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //MARK : ACTIONS
    func calcAge(birthday:String) -> Int{
        let dateFormater = NSDateFormatter()
        dateFormater.dateFormat = "yyyy"
        let birthdayDate = dateFormater.dateFromString(birthday)
        let calendar: NSCalendar! = NSCalendar(calendarIdentifier: NSCalendarIdentifierGregorian)
        let now: NSDate! = NSDate()
        let calcAge = calendar.components(.Year, fromDate: birthdayDate!, toDate: now, options: [])
        let age = calcAge.year
        return age
    }
    
 
    
    
    
    @IBAction func ageVerifyButton(sender: UIButton) {
        
   
        let birthYearInt = Int(birthYearTextField.text!)
        let birthMath = 2016 - birthYearInt!
        if birthMath >= 21 {
            ageResultLabel.text = "You're old enough to drive and vote and buy liquor"
        }else if birthMath >= 18 {
            ageResultLabel.text = "You're old enough to drive and vote"
        } else if birthMath >= 16 {
           ageResultLabel.text = "You're old enough to drive"
        } else {
            ageResultLabel.text = "get off my lawn"
        }
    
    

    
}
}

