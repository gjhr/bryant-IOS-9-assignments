//
//  guessViewController.swift
//  Assignment2
//
//  Created by Geoff Bryant on 7/3/16.
//  Copyright © 2016 Geoff Bryant. All rights reserved.
//

import Foundation
import UIKit

class GuessViewController: UIViewController {
    
    
    
    
    
    @IBOutlet weak var guessResultLabel: UILabel!
    
    @IBOutlet weak var guessTextField: UITextField!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK : ACTIONS
    
   
    @IBAction func guessButton(sender: UIButton) {
        let guessInt = Int(guessTextField.text!)
        let randomNumber = arc4random_uniform(11)
        if guessInt == 0 {
           return guessResultLabel.text = "i said between 1 and 10"
        }
        if guessInt > 10 {
            return guessResultLabel.text = "i said between 1 and 10"
        }
        if guessInt == Int(randomNumber) {
            guessResultLabel.text = "You chose wisely"
        } else {
            guessResultLabel.text = "He chose poorly"
        }
    }
    
    
    
    
    
}

