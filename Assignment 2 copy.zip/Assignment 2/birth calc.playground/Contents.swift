//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


//subtract birth year from 2016, then use the old enough to vote stuff

func birthYearCalc (birthYearInt: Int) {
    let birthMath = 2016 - birthYearInt
    print ("\(birthMath)")
}

birthYearCalc(1979)



birthYearCalc(2000)
birthYearCalc(2017)



func birthYearCalc2 (birthYearInt: Int) {
    let birthMath = 2016 - birthYearInt
    if birthMath >= 21 {
        print ("all three")
    }else if birthMath >= 18 {
        print ("drive and vote")
    } else if birthMath >= 16 {
        print ("just drive")
    } else {
        print ("get off my lawn")
    }
}

birthYearCalc2(1979)
birthYearCalc2(2002)
birthYearCalc2(1996)
birthYearCalc2(2099)

