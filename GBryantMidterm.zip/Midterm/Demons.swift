//
//  Demons.swift
//  Midterm
//
//  Created by Geoff Bryant on 8/1/16.
//  Copyright © 2016 Geoff Bryant. All rights reserved.
//

import Foundation

import UIKit

//protocol Demon {
//    var demonName: String { get }
//    var demonCost: Float { get }
//    
//}


class DemonObject: NSObject {
    
    let demonName:String
    let demonCost: Double
//    let demonImage: UIImage???
    
    init(demonName: String, demonCost: Double) {
        self.demonName = demonName
        self.demonCost = demonCost
//        self.demonImage = demonImage
        
    }
    
    
}