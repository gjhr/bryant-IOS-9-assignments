//
//  RegisterViewController.swift
//  Midterm
//
//  Created by Geoff Bryant on 8/1/16.
//  Copyright © 2016 Geoff Bryant. All rights reserved.
//

import Foundation

import UIKit

class RegisterViewController: UITableViewController {
    
    var demons = [DemonObject]()
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "shoppinglistsegueidentifier" {
            if
                let addNavigationController = segue.destinationViewController as? UINavigationController,
                let shoppingListViewController = addNavigationController.topViewController as?ShoppingListViewController
            
            
//            if let ShoppingListViewController = segue.destinationViewController as? UINavigationController,
            
            {
                shoppingListViewController.delegate = self
                if let indexpath = tableView.indexPathForSelectedRow {
                    let demonsCell = demons[indexpath.row]
//                    ShoppingListViewController.demons = demons
                    
                      print(demonsCell.demonCost)
                    
                } else {

                }
            }
        }
        if segue.identifier == "checkoutviewsegue" {
            if
                let checkoutViewController = segue.destinationViewController as? CheckoutViewController {
                 checkoutViewController.demons = demons
                //                        } }} }
            }
        }
    }
//    @IBAction func CheckoutButtonAction(sender: AnyObject) {
//        
//        prepareForSegue(UIStoryboardSegue, sender: AnyObject?){
//            if segue.identifier == "checkoutviewsegue" {
//                if let checkoutViewController = segue.destinationViewController as? CheckoutViewController {
//                    demons = CheckoutViewController.demons
//                }
//            }
//        }
    
//    override func prepareFor
    
    //MARK: UITABLEVIEWDATASOURCE
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(demons.count)
        return demons.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let shoppingListVC = ShoppingListViewController()
        shoppingListVC.delegate = self
//        ShoppingListViewController.delegate? = self
        
        let cell = tableView.dequeueReusableCellWithIdentifier("maincellidentifier", forIndexPath: indexPath)
        
        let demonsCell = demons[indexPath.row]
        cell.textLabel?.text = demonsCell.demonName
        cell.detailTextLabel?.text = "\(demonsCell.demonCost)"
      
//        print(demonsCell.demonCost)
        
//        for demonCost in demons {
//            print ("\(demonCost)")
//        }
        
        return cell
        
        
    
        
    }
    
    @IBAction func removeAllButton(sender: AnyObject) {
     demons.removeAll()
        tableView.reloadData()
    }
     }







extension RegisterViewController: DemonShoppingListDelegate {
    func MoveDemonToShoppingList(item: DemonObject) {
        demons.append(item)
        tableView.reloadData()
        var summ: Double = 0
        for demon in demons {
//            let sum = demon.demonCost.reduce(0,+)
            
            print ("\(demon.demonCost)")
            summ += demon.demonCost
            print(summ)
        }
     
      
    }
//    func printTest {
//    for demonCost in demons {
//    print ("\(demonCost)")
//    }
//    }
    
  
}




