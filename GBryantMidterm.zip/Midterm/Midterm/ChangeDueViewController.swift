//
//  ChangeDueViewController.swift
//  Midterm
//
//  Created by Geoff Bryant on 8/1/16.
//  Copyright © 2016 Geoff Bryant. All rights reserved.
//

import Foundation

import UIKit

class ChangeDueViewController: UIViewController {
    
    
    
    @IBOutlet weak var changeDueLabel: UILabel!
    
    
    @IBOutlet weak var otherLabel: UILabel!
    
    
    
    var cashInput: Double?
    var demons: [DemonObject]?
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        var sumSub: Double = 0
        for demon in demons!{
            sumSub += demon.demonCost
        }
        let totalWTip = Double(sumSub * 1.08875)
        let roundedTotal = round(totalWTip * 100) / 100
        if cashInput < roundedTotal {
            otherLabel.text = "INSUFFICIENT FUNDS"
            changeDueLabel.text = "Please hit CANCEL, go back and pay in full.  Cheapskate."
        } else {
            let changeDueMath = Double(cashInput! - roundedTotal)
            otherLabel.text = "Thank you. Come again."
            changeDueLabel.text = "$\(changeDueMath)"
        }
        
        
        
        
//    changeDueLabel.text = "\(cashInput)"
        
        
    }
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        
//
//
//        NSNotificationCenter.defaultCenter().addObserver(self, selector: changeMath, name: "passData", object: nil)
//        
//        func changeMath (notification: NSNotification) {
//            changeDueLabel.text = notification.userInfo!["key"]
//        }
        
        
        
        }
    @IBAction func CanceButtonAction(sender: AnyObject) {
        
        dismissViewControllerAnimated(true, completion: nil)
    }
        
    }
    
    
