//
//  ShoppingListViewController.swift
//  Midterm
//
//  Created by Geoff Bryant on 8/1/16.
//  Copyright © 2016 Geoff Bryant. All rights reserved.
//

import Foundation

//protocol DemonProtocol {
//    var demonName: String { get }
//    var demonCost: Float { get }
//    var demonImage: UIImage { get }
//    
//    
//    
//}

import UIKit

protocol DemonShoppingListDelegate: class {
    func MoveDemonToShoppingList(item: DemonObject)
    
}
//    // DemonObject?
//    
//    
//    }
//
//
class ShoppingListViewController: UIViewController {
    
    weak var delegate: DemonShoppingListDelegate?
    
    
    
    @IBOutlet weak var LuciferButtonObject: UIButton!
    
    @IBOutlet weak var LeviathanButtonObject: UIButton!
    
    @IBOutlet weak var SatanButtonObject: UIButton!
    
    @IBOutlet weak var BelialButtonObject: UIButton!
    
    @IBOutlet weak var CancelButtonObject: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        let demonItems = [
//                DemonObject(demonName: "LUCIFER", demonCost: 6.66, demonImage: UIImage(named: "luciferImage")!),
//                DemonObject(demonName: "LEVIATHAN", demonCost: 28000000.00, demonImage: UIImage(named: "leviathanImage")!),
//                DemonObject(demonName: "SATAN", demonCost: 66.60, demonImage: UIImage(named: "satanImage")!),
//                DemonObject(demonName: "BELIAL", demonCost: 666.00, demonImage: UIImage(named: "belialImage")!)
//                    ]
//        LuciferButtonObject.imageView = UIImage(named: "luciferImage")
        
    }
    
    @IBAction func LuciferButtonAction(sender: AnyObject) {
        let demonName = "LUCIFER"
        let demonCost = 6.66
        
       
        let infoFromButton = DemonObject(demonName: demonName, demonCost: demonCost)
        delegate?.MoveDemonToShoppingList(infoFromButton)
      
        print(demonName)
        
        dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    @IBAction func LeviathanButtonAction(sender: AnyObject) {
        let demonName = "LEVIATHAN"
        let demonCost = 28000000.00
        
        
        let infoFromButton = DemonObject(demonName: demonName, demonCost: demonCost)
        delegate?.MoveDemonToShoppingList(infoFromButton)
        
        dismissViewControllerAnimated(true, completion: nil)
     
        print(demonName)
    }
    
    
    @IBAction func SatanButtonAction(sender: AnyObject) {
        let demonName = "SATAN"
        let demonCost = 66.60
        
        
        let infoFromButton = DemonObject(demonName: demonName, demonCost: demonCost)
        delegate?.MoveDemonToShoppingList(infoFromButton)
        
        dismissViewControllerAnimated(true, completion: nil)

        print(demonName)
        
    }
    
    @IBAction func BelialButtonAction(sender: AnyObject) {
        
        
        let demonName = "BELIAL"
        let demonCost = 666.00
        
        
        let infoFromButton = DemonObject(demonName: demonName, demonCost: demonCost)
        delegate?.MoveDemonToShoppingList(infoFromButton)
        
        dismissViewControllerAnimated(true, completion: nil)
        

        print(demonName)
    }
    
    
    
    
    @IBAction func CancelButtonAction(sender: AnyObject) {
        
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    
    
}
//
////
//    weak var delegate: DemonShoppingListDelegate?
//    
//    var demons = [DemonObject]()
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//        let demonItems = [
//        DemonObject(demonName: "LUCIFER", demonCost: 6.66, demonImage: UIImage(named: "luciferImage")!),
//        DemonObject(demonName: "LEVIATHAN", demonCost: 28000000.00, demonImage: UIImage(named: "leviathanImage")!),
//        DemonObject(demonName: "SATAN", demonCost: 66.60, demonImage: UIImage(named: "satanImage")!),
//        DemonObject(demonName: "BELIAL", demonCost: 666.00, demonImage: UIImage(named: "belialImage")!)
//            ]
//        }

  //IBAction to connect the buttons above to something?  
    // Loading the previous VC and moving the data over
    
    // there's somethign in the TODO.app that moves the data from one VC to a new TV cell - do that.
    // figure out tableview.count to get the "# of items" on the Checkout VC
    
    // delgate on the checkout button on 1st Register VC, conforming to protocol created on teh resulting Checkout VC?
    
    // test field on Checkout VC needs to "validate"  - make sure that input is larger than the total/subtotal or return some sort of error.  Use number pad for input to prevent entering non-numeric characters
    
    
    
    
    
