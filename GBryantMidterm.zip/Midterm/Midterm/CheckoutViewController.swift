//
//  CheckoutViewController.swift
//  Midterm
//
//  Created by Geoff Bryant on 8/1/16.
//  Copyright © 2016 Geoff Bryant. All rights reserved.
//

import Foundation

import UIKit

class CheckoutViewController: UIViewController {
    
//    private var demons = [DemonObject]()
    
    
    // FIX THE IB OUTLETS DUE TO NEW LAYOUT!!!!!!!!!  DONE?
    

    
    
    @IBOutlet weak var totalDueLabel: UILabel!
    
    @IBOutlet weak var numberOfItemsLabel: UILabel!
    
    @IBOutlet weak var subtotalLabel: UILabel!
    
    @IBOutlet weak var cashInputTextField: UITextField!
    
    @IBOutlet weak var errorLabel: UILabel!
    
    @IBOutlet weak var checkoutButtonObject: UIButton!
    
    
    //    something DOT count = numberofitemslabel
    
    //    ??demon.demoncost math = subtotal
    
//    IB checkout button to last VC
    
//    code checkout button to last VC
    
//    validation of input field .  Playgrounds?
    
//    error label for nonvalidated input?
    
    
    
    
    
    
    
    
    
    
    
    
    
    var demons: [DemonObject]?
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        if let demons = demons {
            
            for demon in demons {
                print("\(demon.demonCost)")
            }
            
        }
        var sumSub: Double = 0
        for demon in demons! {
            sumSub += demon.demonCost
            print(sumSub)
             numberOfItemsLabel.text = "\(demons!.count)"
            subtotalLabel.text = "$\(sumSub)"
            
            let totalWTip = Double(sumSub * 1.08875)
            let roundedTotal = round(totalWTip * 100) / 100
            totalDueLabel.text = "$\(roundedTotal)"
        }
    }
    

    
    override func viewDidLoad() {
        super.viewDidLoad()

//        if let demons = demons {
//             var summ: Double = 0
//            for demon in demons {
////                print("\(demon.demonCost)")
//
//               
//             
//                    //            let sum = demon.demonCost.reduce(0,+)
//                    
//                    print ("\(demon.demonCost)")
//                    summ += demon.demonCost
//                    print(summ)
////            subtotalLabel.text = "\(summ)"
//            }
//            
//        }
//
//        
//     numberOfItemsLabel.text = "\(demons?.count)"
//        
//        var sumSub: Double = 0
//        for demon in demons! {
//            sumSub += demon.demonCost
//        }
//     subtotalLabel.text = "$\(sumSub)"
//        
//     
//        let totalWTip = Double(sumSub * 1.08875)
//     totalDueLabel.text = "\(totalWTip)"
//        
//        let changedictionary = ["key": totalWTip]
//        NSNotificationCenter.defaultCenter().postNotificationName("passData", object: nil, userInfo: changedictionary)
        
//          NSNotificationCenter.defaultCenter().postNotificationName(totalDueLabel.text!, object: totalWTip)
        
        
//     subtotalLabel.text = "$\(summ)"
        
        
        
        
        
 }

//    @IBAction func checkoutButtonAction(sender: AnyObject) {
//        
//        let cashInput = Double(cashInputTextField.text!)
//        var sumSub: Double = 0
//        for demon in demons! {
//            sumSub += demon.demonCost
//        }
//        let totalWTip = Double(sumSub * 1.08875)
//         let roundedTotal = round(totalWTip * 100) / 100
//        if cashInput < roundedTotal {
//         return   errorLabel.text = "Insufficient funds"
//            
//            
//        } else {
//            prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?){
//                if segue.identifier == "changeduesequeID"
            
            
            
//            let storyboard = UIStoryboard(name: ChangeDueVC, bundle: nil)
//            if
//                let addNavigationController = storyboard!.instantiateViewControllerWithIdentifier("ChangeDueNC") as? UINavigationController,
//                let changeDueVC = addNavigationController.topViewController as? ChangeDueViewController {
////                presentViewController(addNavigationController, animated: true)
//            }
    
        
        
//        }
    
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let cashInput = Double(cashInputTextField.text!)
        var sumSub: Double = 0
        for demon in demons! {
            sumSub += demon.demonCost
        }
        let totalWTip = Double(sumSub * 1.08875)
         let roundedTotal = round(totalWTip * 100) / 100
//        if cashInput < roundedTotal {
//            
//         errorLabel.text = "Insufficient funds"
//        }
//    else {
            if segue.identifier == "changedueVCsegue" {
                if
                    let addNavigationController = segue.destinationViewController as?
                UINavigationController,
                    let ChangeDueViewController = addNavigationController.topViewController as? ChangeDueViewController
                {
                    ChangeDueViewController.demons = demons
                    ChangeDueViewController.cashInput = cashInput
                    print("worked")
                }
            }
        }
//    }
    
    
    
    
    
    


        
        

//    }
// number of items - something.count, from the tableview
    
//subtotal?  Still a big problem.
    
//Can I get rid of the error label?  Have that returned in the text field?


//    let multiples = [...]
//    sum = multiples.reduce(0, combine: +)




}
